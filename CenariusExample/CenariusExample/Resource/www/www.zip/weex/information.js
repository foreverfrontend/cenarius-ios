// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _foo = __webpack_require__(1);

	var _foo2 = _interopRequireDefault(_foo);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	// const stream = weex.requireModule('stream')
	// stream.fetch({
	//       method: 'GET',
	//       url: `https://www-test.infinitus.com.cn/front/api/json?username=invoke&password=abc123&method=CMSBannerList&params=%7B%22code%22%3A%22appcsbanner%22%7Dn`,
	//       type: 'json'
	//     }, (response) => {
	//       if (response.status == 200) {
	//       console.log("------------------------"+response)
	//       }
	//       else {
	//         console.log(222)
	//       }
	//     })

	_foo2.default.el = '#root';
	exports.default = new Vue(_foo2.default);

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	
	/* styles */
	__webpack_require__(2)

	var Component = __webpack_require__(7)(
	  /* script */
	  __webpack_require__(8),
	  /* template */
	  __webpack_require__(9),
	  /* scopeId */
	  "data-v-3eabb71d",
	  /* cssModules */
	  null
	)
	Component.options.__file = "E:\\work\\text\\awesome-project\\src\\foo.vue"
	if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
	if (Component.options.functional) {console.error("[vue-loader] foo.vue: functional components are not supported with templates, they should use render functions.")}

	/* hot reload */
	if (false) {(function () {
	  var hotAPI = require("vue-hot-reload-api")
	  hotAPI.install(require("vue"), false)
	  if (!hotAPI.compatible) return
	  module.hot.accept()
	  if (!module.hot.data) {
	    hotAPI.createRecord("data-v-3eabb71d", Component.options)
	  } else {
	    hotAPI.reload("data-v-3eabb71d", Component.options)
	  }
	})()}

	module.exports = Component.exports


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	// style-loader: Adds some css to the DOM by adding a <style> tag

	// load the styles
	var content = __webpack_require__(3);
	if(typeof content === 'string') content = [[module.id, content, '']];
	if(content.locals) module.exports = content.locals;
	// add the styles to the DOM
	var update = __webpack_require__(5)("57dd7240", content, false);
	// Hot Module Replacement
	if(false) {
	 // When the styles change, update the <style> tags
	 if(!content.locals) {
	   module.hot.accept("!!../node_modules/css-loader/index.js!../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-3eabb71d&scoped=true!../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./foo.vue", function() {
	     var newContent = require("!!../node_modules/css-loader/index.js!../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-3eabb71d&scoped=true!../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./foo.vue");
	     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
	     update(newContent);
	   });
	 }
	 // When the module is disposed, remove the <style> tags
	 module.hot.dispose(function() { update(); });
	}

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(4)();
	// imports


	// module
	exports.push([module.id, "\n.header[data-v-3eabb71d] {\n}\n.image[data-v-3eabb71d] {\n  width: 750px;\n  height: 422px;\n}\n.slider[data-v-3eabb71d] {\n  height: 422px;\n}\n.frame[data-v-3eabb71d] {\n  width: 750px;\n  height: 422px;\n  position: relative;\n}\n.mask[data-v-3eabb71d] {\n  position: absolute;\n  bottom: 0;\n  width: 750px;\n  height: 58px;\n  background-color: rgba(40, 40, 40, 0.3);\n  box-sizing: border-box;\n  padding: 10px;\n  color: #ffffff;\n  font-size: 30px;\n  overflow: hidden;\n}\n.text[data-v-3eabb71d] {\n  width: 500px;\n  height: 38px;\n  line-height: 39px;\n  color: #ffffff;\n  font-size: 34px;\n  display: block;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.indicators[data-v-3eabb71d] {\n  width: 700px;\n  height: 700px;\n  item-color: #888888;\n  item-selected-color: #ffffff;\n  item-size: 24px;\n  position: absolute;\n  top: 44px;\n  left: 280px;\n}\n.list[data-v-3eabb71d] {\n  margin-bottom: 3px;\n  position: relative;\n  width: 750px;\n  overflow: hidden;\n  border-bottom-width: 2px;\n  border-bottom-style: solid;\n  border-bottom-color: #dfdfdd;\n  padding-top: 24px;\n  padding-right: 16px;\n  padding-bottom: 24px;\n  padding-left: 16px;\n  box-sizing: border-box;\n  flex-direction: row;\n}\n.images[data-v-3eabb71d] {\n  width: 300px;\n  height: 165px;\n  border-radius: 10px;\n  flex: 1;\n  position: left;\n}\n.content[data-v-3eabb71d] {\n  width: 300px;\n  height: 165px;\n  position: right;\n  left: 20px;\n  flex: 2;\n}\n.catalogname[data-v-3eabb71d] {\n  display: inline-block;\n  font-size: 24px;\n  position: absolute;\n  top: 128px;\n  color: gray;\n}\n.publishdate[data-v-3eabb71d] {\n  display: inline-block;\n  font-size: 24px;\n  position: absolute;\n  top: 132px;\n  right: 16px;\n  color: gray;\n}\n.loading-view[data-v-3eabb71d] {\n  height: 80px;\n  width: 750px;\n  justify-content: center;\n  align-items: center;\n  background-color: #c0c0c0;\n}\n.indicator[data-v-3eabb71d] {\n  height: 40px;\n  width: 40px;\n  color: #45b5f0;\n}\n", ""]);

	// exports


/***/ }),
/* 4 */
/***/ (function(module, exports) {

	/*
		MIT License http://www.opensource.org/licenses/mit-license.php
		Author Tobias Koppers @sokra
	*/
	// css base code, injected by the css-loader
	module.exports = function() {
		var list = [];

		// return the list of modules as css string
		list.toString = function toString() {
			var result = [];
			for(var i = 0; i < this.length; i++) {
				var item = this[i];
				if(item[2]) {
					result.push("@media " + item[2] + "{" + item[1] + "}");
				} else {
					result.push(item[1]);
				}
			}
			return result.join("");
		};

		// import a list of modules into the list
		list.i = function(modules, mediaQuery) {
			if(typeof modules === "string")
				modules = [[null, modules, ""]];
			var alreadyImportedModules = {};
			for(var i = 0; i < this.length; i++) {
				var id = this[i][0];
				if(typeof id === "number")
					alreadyImportedModules[id] = true;
			}
			for(i = 0; i < modules.length; i++) {
				var item = modules[i];
				// skip already imported module
				// this implementation is not 100% perfect for weird media query combinations
				//  when a module is imported multiple times with different media queries.
				//  I hope this will never occur (Hey this way we have smaller bundles)
				if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
					if(mediaQuery && !item[2]) {
						item[2] = mediaQuery;
					} else if(mediaQuery) {
						item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
					}
					list.push(item);
				}
			}
		};
		return list;
	};


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	/*
	  MIT License http://www.opensource.org/licenses/mit-license.php
	  Author Tobias Koppers @sokra
	  Modified by Evan You @yyx990803
	*/

	var hasDocument = typeof document !== 'undefined'

	if (false) {
	  if (!hasDocument) {
	    throw new Error(
	    'vue-style-loader cannot be used in a non-browser environment. ' +
	    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
	  ) }
	}

	var listToStyles = __webpack_require__(6)

	/*
	type StyleObject = {
	  id: number;
	  parts: Array<StyleObjectPart>
	}

	type StyleObjectPart = {
	  css: string;
	  media: string;
	  sourceMap: ?string
	}
	*/

	var stylesInDom = {/*
	  [id: number]: {
	    id: number,
	    refs: number,
	    parts: Array<(obj?: StyleObjectPart) => void>
	  }
	*/}

	var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
	var singletonElement = null
	var singletonCounter = 0
	var isProduction = false
	var noop = function () {}

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

	module.exports = function (parentId, list, _isProduction) {
	  isProduction = _isProduction

	  var styles = listToStyles(parentId, list)
	  addStylesToDom(styles)

	  return function update (newList) {
	    var mayRemove = []
	    for (var i = 0; i < styles.length; i++) {
	      var item = styles[i]
	      var domStyle = stylesInDom[item.id]
	      domStyle.refs--
	      mayRemove.push(domStyle)
	    }
	    if (newList) {
	      styles = listToStyles(parentId, newList)
	      addStylesToDom(styles)
	    } else {
	      styles = []
	    }
	    for (var i = 0; i < mayRemove.length; i++) {
	      var domStyle = mayRemove[i]
	      if (domStyle.refs === 0) {
	        for (var j = 0; j < domStyle.parts.length; j++) {
	          domStyle.parts[j]()
	        }
	        delete stylesInDom[domStyle.id]
	      }
	    }
	  }
	}

	function addStylesToDom (styles /* Array<StyleObject> */) {
	  for (var i = 0; i < styles.length; i++) {
	    var item = styles[i]
	    var domStyle = stylesInDom[item.id]
	    if (domStyle) {
	      domStyle.refs++
	      for (var j = 0; j < domStyle.parts.length; j++) {
	        domStyle.parts[j](item.parts[j])
	      }
	      for (; j < item.parts.length; j++) {
	        domStyle.parts.push(addStyle(item.parts[j]))
	      }
	      if (domStyle.parts.length > item.parts.length) {
	        domStyle.parts.length = item.parts.length
	      }
	    } else {
	      var parts = []
	      for (var j = 0; j < item.parts.length; j++) {
	        parts.push(addStyle(item.parts[j]))
	      }
	      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
	    }
	  }
	}

	function createStyleElement () {
	  var styleElement = document.createElement('style')
	  styleElement.type = 'text/css'
	  head.appendChild(styleElement)
	  return styleElement
	}

	function addStyle (obj /* StyleObjectPart */) {
	  var update, remove
	  var styleElement = document.querySelector('style[data-vue-ssr-id~="' + obj.id + '"]')

	  if (styleElement) {
	    if (isProduction) {
	      // has SSR styles and in production mode.
	      // simply do nothing.
	      return noop
	    } else {
	      // has SSR styles but in dev mode.
	      // for some reason Chrome can't handle source map in server-rendered
	      // style tags - source maps in <style> only works if the style tag is
	      // created and inserted dynamically. So we remove the server rendered
	      // styles and inject new ones.
	      styleElement.parentNode.removeChild(styleElement)
	    }
	  }

	  if (isOldIE) {
	    // use singleton mode for IE9.
	    var styleIndex = singletonCounter++
	    styleElement = singletonElement || (singletonElement = createStyleElement())
	    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
	    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
	  } else {
	    // use multi-style-tag mode in all other cases
	    styleElement = createStyleElement()
	    update = applyToTag.bind(null, styleElement)
	    remove = function () {
	      styleElement.parentNode.removeChild(styleElement)
	    }
	  }

	  update(obj)

	  return function updateStyle (newObj /* StyleObjectPart */) {
	    if (newObj) {
	      if (newObj.css === obj.css &&
	          newObj.media === obj.media &&
	          newObj.sourceMap === obj.sourceMap) {
	        return
	      }
	      update(obj = newObj)
	    } else {
	      remove()
	    }
	  }
	}

	var replaceText = (function () {
	  var textStore = []

	  return function (index, replacement) {
	    textStore[index] = replacement
	    return textStore.filter(Boolean).join('\n')
	  }
	})()

	function applyToSingletonTag (styleElement, index, remove, obj) {
	  var css = remove ? '' : obj.css

	  if (styleElement.styleSheet) {
	    styleElement.styleSheet.cssText = replaceText(index, css)
	  } else {
	    var cssNode = document.createTextNode(css)
	    var childNodes = styleElement.childNodes
	    if (childNodes[index]) styleElement.removeChild(childNodes[index])
	    if (childNodes.length) {
	      styleElement.insertBefore(cssNode, childNodes[index])
	    } else {
	      styleElement.appendChild(cssNode)
	    }
	  }
	}

	function applyToTag (styleElement, obj) {
	  var css = obj.css
	  var media = obj.media
	  var sourceMap = obj.sourceMap

	  if (media) {
	    styleElement.setAttribute('media', media)
	  }

	  if (sourceMap) {
	    // https://developer.chrome.com/devtools/docs/javascript-debugging
	    // this makes source maps inside style tags work properly in Chrome
	    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
	    // http://stackoverflow.com/a/26603875
	    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
	  }

	  if (styleElement.styleSheet) {
	    styleElement.styleSheet.cssText = css
	  } else {
	    while (styleElement.firstChild) {
	      styleElement.removeChild(styleElement.firstChild)
	    }
	    styleElement.appendChild(document.createTextNode(css))
	  }
	}


/***/ }),
/* 6 */
/***/ (function(module, exports) {

	/**
	 * Translates the list format produced by css-loader into something
	 * easier to manipulate.
	 */
	module.exports = function listToStyles (parentId, list) {
	  var styles = []
	  var newStyles = {}
	  for (var i = 0; i < list.length; i++) {
	    var item = list[i]
	    var id = item[0]
	    var css = item[1]
	    var media = item[2]
	    var sourceMap = item[3]
	    var part = {
	      id: parentId + ':' + i,
	      css: css,
	      media: media,
	      sourceMap: sourceMap
	    }
	    if (!newStyles[id]) {
	      styles.push(newStyles[id] = { id: id, parts: [part] })
	    } else {
	      newStyles[id].parts.push(part)
	    }
	  }
	  return styles
	}


/***/ }),
/* 7 */
/***/ (function(module, exports) {

	module.exports = function normalizeComponent (
	  rawScriptExports,
	  compiledTemplate,
	  scopeId,
	  cssModules
	) {
	  var esModule
	  var scriptExports = rawScriptExports = rawScriptExports || {}

	  // ES6 modules interop
	  var type = typeof rawScriptExports.default
	  if (type === 'object' || type === 'function') {
	    esModule = rawScriptExports
	    scriptExports = rawScriptExports.default
	  }

	  // Vue.extend constructor export interop
	  var options = typeof scriptExports === 'function'
	    ? scriptExports.options
	    : scriptExports

	  // render functions
	  if (compiledTemplate) {
	    options.render = compiledTemplate.render
	    options.staticRenderFns = compiledTemplate.staticRenderFns
	  }

	  // scopedId
	  if (scopeId) {
	    options._scopeId = scopeId
	  }

	  // inject cssModules
	  if (cssModules) {
	    var computed = options.computed || (options.computed = {})
	    Object.keys(cssModules).forEach(function (key) {
	      var module = cssModules[key]
	      computed[key] = function () { return module }
	    })
	  }

	  return {
	    esModule: esModule,
	    exports: scriptExports,
	    options: options
	  }
	}


/***/ }),
/* 8 */
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var stream = weex.requireModule('stream');
	exports.default = {
	  data: function data() {
	    return {
	      count: 1,
	      loading_display: 'hide',
	      imageList: [{ src: 'https://cmsqn-test.infinitus.com.cn/upload/resources/image/2017/02/06/52232.jpg', text: '内部打开外链' }, { src: 'https://www-test.infinitus.com.cn/upload/resources/image/2017/02/17/52809.jpg', text: '【打开方式：外部】无限极网站。' }, { src: 'https://www-test.infinitus.com.cn/upload/resources/image/2017/01/05/51151.jpg', text: '【视频】中国智能手机用户分析' }, { src: 'https://cmsqn-test.infinitus.com.cn/upload/resources/image/2017/02/08/52242.jpg', text: '【内部栏目】公司新闻' }, { src: 'https://cmsqn-test.infinitus.com.cn/upload/resources/image/2017/02/08/52245.jpg', text: '【图】2016亲情之旅：在世上最幸福的国度，面朝大海心暖花开' }],
	      itemList: []
	    };
	  },

	  methods: {
	    onloading: function onloading() {
	      this.loading_display = 'show';
	      this.count += 1;
	      this.request();
	    },
	    request: function request() {
	      var self = this;
	      var params = encodeURIComponent(JSON.stringify({ navItemID: '170', pageIndex: +this.count, pageSize: '15' }));
	      stream.fetch({
	        method: 'GET',
	        url: 'https://www-test.infinitus.com.cn/front/api/json?username=invoke&password=abc123&method=CMSNavContentListData&params=' + params,
	        type: 'json'
	      }, function (response) {
	        if (response.status === 200) {
	          var moreList = response.data.Data;
	          var delay = self.itemList.length === 0 ? 0 : 1000;
	          setTimeout(function () {
	            for (var i = 0; i < moreList.length; i += 1) {
	              self.itemList.push(moreList[i]);
	            }
	            self.loading_display = 'hide';
	          }, delay);
	        } else {
	          console.log(222);
	        }
	      });
	    }
	  },
	  created: function created() {
	    this.request();
	  }
	};

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', [_c('list', {
	    attrs: {
	      "show-scrollbar": false
	    }
	  }, [_c('cell', {
	    staticClass: "header"
	  }, [_c('slider', {
	    staticClass: "slider",
	    attrs: {
	      "interval": "3000",
	      "auto-play": "true"
	    }
	  }, [_vm._l((_vm.imageList), function(img) {
	    return _c('div', {
	      staticClass: "frame"
	    }, [_c('image', {
	      staticClass: "image",
	      attrs: {
	        "resize": "cover",
	        "src": img.src
	      }
	    }), _vm._v(" "), _c('div', {
	      staticClass: "mask"
	    }, [_c('div', [_c('text', {
	      staticClass: "text",
	      attrs: {
	        "src": img.text
	      }
	    }, [_vm._v(_vm._s(img.text))])])])])
	  }), _vm._v(" "), _c('indicator', {
	    staticClass: "indicators"
	  })], 2)], 1), _vm._v(" "), _vm._l((_vm.itemList), function(item) {
	    return _c('cell', {
	      staticClass: "list"
	    }, [(item.LogoFile) ? _c('image', {
	      staticClass: "images",
	      attrs: {
	        "src": item.LogoFile
	      }
	    }) : _vm._e(), _vm._v(" "), _c('div', {
	      staticClass: "content"
	    }, [(item.Title) ? _c('text', [_vm._v(_vm._s(item.Title))]) : _vm._e(), _vm._v(" "), (item.CatalogName) ? _c('text', {
	      staticClass: "catalogname"
	    }, [_vm._v(_vm._s(item.CatalogName))]) : _vm._e(), _vm._v(" "), (item.PublishDate) ? _c('text', {
	      staticClass: "publishdate"
	    }, [_vm._v(_vm._s(item.PublishDate.split(" ")[0]))]) : _vm._e()])])
	  }), _vm._v(" "), _c('loading', {
	    staticClass: "loading-view",
	    attrs: {
	      "display": _vm.loading_display
	    },
	    on: {
	      "loading": _vm.onloading
	    }
	  }, [_c('loading-indicator', {
	    staticStyle: {
	      "height": "60px",
	      "width": "60px"
	    }
	  })], 1)], 2)], 1)
	},staticRenderFns: []}
	module.exports.render._withStripped = true
	if (false) {
	  module.hot.accept()
	  if (module.hot.data) {
	     require("vue-hot-reload-api").rerender("data-v-3eabb71d", module.exports)
	  }
	}

/***/ })
/******/ ]);